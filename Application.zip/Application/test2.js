var nu = require("./numeric.min.js");


A = [[1,2,3],[4,5]]

B = {1:2,2:1}
console.log (B);
// console.log (nu.transpose(nu.transpose(A)));