SLW = require("simple-livescript-watch");

SLW();
